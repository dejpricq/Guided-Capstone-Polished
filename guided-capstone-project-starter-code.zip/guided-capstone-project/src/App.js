import styles from "./App.module.css";

function App ()
{
  return (
    <>
      Guided Capstone Project
    </>
  );
}

export default App;
